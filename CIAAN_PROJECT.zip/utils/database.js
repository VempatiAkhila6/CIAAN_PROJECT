// Database utilities
const initializeDatabase = async () => {
  try {
    // Initialize with sample users if no users exist
    const existingUsers = await trickleListObjects('user', 5, true);
    
    if (existingUsers.items.length === 0) {
      // Create sample users
      const sampleUsers = [
        {
          name: 'Akhila',
          email: 'akhila@example.com',
          password: 'password123',
          bio: 'Self Learner passionate about technology and innovation'
        },
        {
          name: 'Bhanu',
          email: 'bhanu@example.com',
          password: 'password123',
          bio: 'Self-motivated and self-taught, learning never stops'
        },
        {
          name: 'Keerthi',
          email: 'keerthi@example.com',
          password: 'password123',
          bio: 'Passionate self-learner exploring new technologies'
        }
      ];

      for (const userData of sampleUsers) {
        await trickleCreateObject('user', {
          ...userData,
          connections: [],
          posts: 0,
          followers: Math.floor(Math.random() * 500) + 50,
          following: Math.floor(Math.random() * 200) + 20
        });
      }
    }
  } catch (error) {
    console.error('Database initialization error:', error);
  }
};

const createPost = async (authorId, content, media = null) => {
  try {
    const post = await trickleCreateObject('post', {
      authorId,
      content,
      media,
      likes: [],
      comments: [],
      timestamp: new Date().toISOString()
    });
    return post;
  } catch (error) {
    console.error('Create post error:', error);
    throw error;
  }
};

const getAllPosts = async () => {
  try {
    const posts = await trickleListObjects('post', 50, true);
    const users = await trickleListObjects('user', 100, true);
    
    // Enrich posts with author information
    const enrichedPosts = posts.items.map(post => {
      const author = users.items.find(u => u.objectId === post.objectData.authorId);
      return {
        ...post,
        author: author ? author.objectData : null
      };
    });
    
    return enrichedPosts.sort((a, b) => new Date(b.objectData.timestamp) - new Date(a.objectData.timestamp));
  } catch (error) {
    console.error('Get posts error:', error);
    return [];
  }
};

const getAllUsers = async () => {
  try {
    const users = await trickleListObjects('user', 100, true);
    return users.items;
  } catch (error) {
    console.error('Get users error:', error);
    return [];
  }
};

const toggleLike = async (postId, userId) => {
  try {
    const post = await trickleGetObject('post', postId);
    const likes = post.objectData.likes || [];
    
    const userLiked = likes.includes(userId);
    const updatedLikes = userLiked 
      ? likes.filter(id => id !== userId)
      : [...likes, userId];
    
    await trickleUpdateObject('post', postId, {
      ...post.objectData,
      likes: updatedLikes
    });
    
    return !userLiked;
  } catch (error) {
    console.error('Toggle like error:', error);
    throw error;
  }
};

const sendFollowRequest = async (fromUserId, toUserId) => {
  try {
    await trickleCreateObject('follow_request', {
      fromUserId,
      toUserId,
      status: 'pending',
      timestamp: new Date().toISOString()
    });
    return true;
  } catch (error) {
    console.error('Send follow request error:', error);
    throw error;
  }
};

const getFollowRequests = async (userId) => {
  try {
    const requests = await trickleListObjects('follow_request', 50, true);
    return requests.items.filter(req => 
      req.objectData.toUserId === userId && req.objectData.status === 'pending'
    );
  } catch (error) {
    console.error('Get follow requests error:', error);
    return [];
  }
};
