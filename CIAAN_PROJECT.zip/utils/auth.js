// Authentication utilities
const AUTH_KEY = 'connecthub_user';

const login = async (email, password) => {
  try {
    const users = await trickleListObjects('user', 100, true);
    const user = users.items.find(u => 
      u.objectData.email === email && u.objectData.password === password
    );
    
    if (user) {
      localStorage.setItem(AUTH_KEY, JSON.stringify(user));
      return { success: true, user };
    } else {
      return { success: false, error: 'Invalid email or password' };
    }
  } catch (error) {
    console.error('Login error:', error);
    return { success: false, error: 'Login failed' };
  }
};

const register = async (userData) => {
  try {
    // Check if user already exists
    const existingUsers = await trickleListObjects('user', 100, true);
    const userExists = existingUsers.items.some(u => u.objectData.email === userData.email);
    
    if (userExists) {
      return { success: false, error: 'User already exists with this email' };
    }

    const newUser = await trickleCreateObject('user', {
      name: userData.name,
      email: userData.email,
      password: userData.password,
      bio: userData.bio || 'Professional looking to connect and grow',
      connections: [],
      posts: 0,
      followers: 0,
      following: 0
    });

    localStorage.setItem(AUTH_KEY, JSON.stringify(newUser));
    return { success: true, user: newUser };
  } catch (error) {
    console.error('Registration error:', error);
    return { success: false, error: 'Registration failed' };
  }
};

const getCurrentUser = () => {
  try {
    const userData = localStorage.getItem(AUTH_KEY);
    return userData ? JSON.parse(userData) : null;
  } catch (error) {
    console.error('Get current user error:', error);
    return null;
  }
};

const logout = () => {
  localStorage.removeItem(AUTH_KEY);
};

const updateUserProfile = async (userId, updates) => {
  try {
    const updatedUser = await trickleUpdateObject('user', userId, updates);
    localStorage.setItem(AUTH_KEY, JSON.stringify(updatedUser));
    return { success: true, user: updatedUser };
  } catch (error) {
    console.error('Update profile error:', error);
    return { success: false, error: 'Failed to update profile' };
  }
};