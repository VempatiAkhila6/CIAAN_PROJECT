# ConnectHub - Professional Community Platform

## Overview
ConnectHub is a modern LinkedIn-like professional networking platform built with React. It enables users to connect, share insights, and grow their professional network through posts, messaging, and profile interactions.

## Features

### Authentication
- User registration and login
- Secure password-based authentication
- Profile management with bio and avatar

### Post Management
- Create text posts with file upload support for images/videos
- Like posts with visual feedback
- Real-time post feed with timestamps
- Rich media display

### User Profiles
- Simplified user profiles with activity overview
- View user's posts and activity
- Follow request system
- Direct messaging between users

### Additional Features
- Follower requests management
- Home navigation from any page
- Settings page with account preferences and security
- Messages page for conversations
- Search functionality
- Notification badges
- Responsive design

## Tech Stack
- **Frontend**: React 18, TailwindCSS
- **Icons**: Lucide Icons
- **Database**: Trickle Database (built-in)
- **Authentication**: Local storage based

## Demo Users
The platform comes with pre-populated demo users:

1. **Akhila** (akhila@example.com)
   - Bio: "Self Learner passionate about technology and innovation"
   - Password: password123

2. **Bhanu** (bhanu@example.com)
   - Bio: "Self-motivated and self-taught, learning never stops"
   - Password: password123

3. **Keerthi** (keerthi@example.com)
   - Bio: "Passionate self-learner exploring new technologies"
   - Password: password123

## File Structure
```
├── index.html              # Main application page
├── app.js                  # Main React application
├── settings.html           # Settings page
├── settings-app.js         # Settings application
├── messages.html           # Messages page
├── messages-app.js         # Messages application
├── style.css              # Global styles
├── utils/
│   ├── auth.js            # Authentication utilities
│   └── database.js        # Database operations
└── components/
    ├── Header.js          # Navigation header with home button
    ├── CreatePost.js      # Post creation with file upload
    ├── PostCard.js        # Individual post display (no comments)
    ├── ProfileCard.js     # User profile component
    ├── AuthModal.js       # Login/register modal
    ├── MessageModal.js    # Direct messaging modal
    └── FollowerRequests.js # Follow requests management
```

## Setup Instructions
1. Open `index.html` in a modern web browser
2. The application will automatically initialize with demo data
3. Register a new account or login with demo credentials
4. Start connecting and sharing!

## Usage
- **Registration**: Click "Join ConnectHub" and fill out the form
- **Login**: Use demo credentials or your registered account
- **Create Posts**: Click the plus icon and share your thoughts
- **Interact**: Like posts, view profiles, and send messages
- **Settings**: Access account preferences via the user menu

## Browser Compatibility
- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+