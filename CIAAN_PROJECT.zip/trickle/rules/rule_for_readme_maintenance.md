When project is updated or new features are added
- Always check if README.md needs updates
- Update feature list if new functionality is added
- Update file structure if new files are created
- Update setup instructions if deployment changes
- Update demo user information if sample data changes
- Keep documentation current and accurate