function ProfileCard({ user, posts, currentUser, onBack, onSendMessage }) {
  try {
    const [isFollowing, setIsFollowing] = React.useState(false);

    const handleFollow = () => {
      setIsFollowing(!isFollowing);
    };

    const handleMessage = () => {
      onSendMessage(user);
    };

    return (
      <div className="space-y-6" data-name="profile-card" data-file="components/ProfileCard.js">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-[var(--primary-color)] hover:underline"
        >
          <div className="icon-arrow-left text-lg"></div>
          Back to Feed
        </button>

        {/* Profile Header */}
        <div className="card p-6">
          <div className="flex items-start gap-6">
            <div className="w-24 h-24 rounded-full bg-[var(--primary-color)] flex items-center justify-center text-white font-bold text-2xl border-4 border-[var(--border-color)]">
              {user.objectData.name.charAt(0).toUpperCase()}
            </div>
            
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">{user.objectData.name}</h1>
              <p className="text-[var(--text-secondary)] mb-4">{user.objectData.bio}</p>
              
              <div className="flex items-center gap-6 text-sm text-[var(--text-muted)] mb-4">
                <span>{user.objectData.followers || 0} followers</span>
                <span>{user.objectData.following || 0} following</span>
                <span>{posts.length} posts</span>
              </div>
              
              {currentUser && currentUser.objectId !== user.objectId && (
                <div className="flex items-center gap-3">
                  <button
                    onClick={handleFollow}
                    className={isFollowing ? 'btn-secondary' : 'btn-primary'}
                  >
                    {isFollowing ? 'Following' : 'Follow'}
                  </button>
                  <button
                    onClick={handleMessage}
                    className="btn-secondary"
                  >
                    Message
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Posts Section */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-4">Posts</h2>
          {posts.length > 0 ? (
            <div className="space-y-4">
              {posts.map(post => (
                <div key={post.objectId} className="border-b border-[var(--border-color)] pb-4 last:border-b-0">
                  <p className="text-[var(--text-primary)] mb-2">{post.objectData.content}</p>
                  <div className="flex items-center gap-4 text-sm text-[var(--text-muted)]">
                    <span>{post.objectData.likes?.length || 0} likes</span>
                    <span>{post.objectData.comments?.length || 0} comments</span>
                    <span>{new Date(post.objectData.timestamp).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-[var(--text-muted)] text-center py-8">
              No posts yet
            </p>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('ProfileCard component error:', error);
    return null;
  }
}