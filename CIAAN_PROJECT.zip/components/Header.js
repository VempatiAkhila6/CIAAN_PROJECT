function Header({ currentUser, onLogin, onLogout, onViewProfile, onGoHome, onShowFollowerRequests }) {
  try {
    const [showUserMenu, setShowUserMenu] = React.useState(false);
    const [searchQuery, setSearchQuery] = React.useState('');

    const handleProfileClick = () => {
      if (currentUser) {
        onViewProfile(currentUser);
        setShowUserMenu(false);
      }
    };

    const navigateToSettings = () => {
      window.location.href = 'settings.html';
    };

    const navigateToMessages = () => {
      window.location.href = 'messages.html';
    };

    return (
      <header className="navbar sticky top-0 z-50" data-name="header" data-file="components/Header.js">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <button onClick={onGoHome} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
              <div className="w-8 h-8 bg-[var(--primary-color)] rounded flex items-center justify-center">
                <div className="icon-home text-white text-lg"></div>
              </div>
              <h1 className="text-xl font-bold text-[var(--primary-color)]">ConnectHub</h1>
            </button>

            {/* Search Bar */}
            {currentUser && (
              <div className="flex-1 max-w-md mx-8">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search professionals..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="input-field pl-10"
                  />
                  <div className="icon-search absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--text-muted)]"></div>
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="flex items-center gap-4">
              {currentUser ? (
                <>
                  <button 
                    onClick={onShowFollowerRequests}
                    className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <div className="icon-user-plus text-xl text-[var(--text-secondary)]"></div>
                    <span className="notification-badge">2</span>
                  </button>
                  
                  <button 
                    onClick={navigateToMessages}
                    className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <div className="icon-message-circle text-xl text-[var(--text-secondary)]"></div>
                    <span className="notification-badge">3</span>
                  </button>
                  
                  <button className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <div className="icon-bell text-xl text-[var(--text-secondary)]"></div>
                    <span className="notification-badge">5</span>
                  </button>

                  <div className="relative">
                    <button
                      onClick={() => setShowUserMenu(!showUserMenu)}
                      className="flex items-center gap-2 p-1 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <div className="w-12 h-12 rounded-full bg-[var(--primary-color)] flex items-center justify-center text-white font-semibold border-2 border-[var(--border-color)]">
                        {currentUser.objectData.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="icon-chevron-down text-sm text-[var(--text-muted)]"></div>
                    </button>

                    {showUserMenu && (
                      <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-[var(--border-color)] py-2">
                        <button
                          onClick={handleProfileClick}
                          className="w-full text-left px-4 py-2 hover:bg-gray-50 flex items-center gap-3"
                        >
                          <div className="icon-user text-lg text-[var(--text-secondary)]"></div>
                          View Profile
                        </button>
                        <button
                          onClick={navigateToSettings}
                          className="w-full text-left px-4 py-2 hover:bg-gray-50 flex items-center gap-3"
                        >
                          <div className="icon-settings text-lg text-[var(--text-secondary)]"></div>
                          Settings
                        </button>
                        <hr className="my-2 border-[var(--border-color)]" />
                        <button
                          onClick={onLogout}
                          className="w-full text-left px-4 py-2 hover:bg-gray-50 text-[var(--danger-color)] flex items-center gap-3"
                        >
                          <div className="icon-log-out text-lg"></div>
                          Sign Out
                        </button>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <button onClick={onLogin} className="btn-primary">
                  Sign In
                </button>
              )}
            </div>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}