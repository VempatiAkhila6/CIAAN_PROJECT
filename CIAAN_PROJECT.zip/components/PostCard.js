function PostCard({ post, currentUser, onLike, onViewProfile }) {
  try {
    const [isLiked, setIsLiked] = React.useState(false);

    React.useEffect(() => {
      if (currentUser && post.objectData.likes) {
        setIsLiked(post.objectData.likes.includes(currentUser.objectId));
      }
    }, [post.objectData.likes, currentUser]);

    const handleLike = () => {
      onLike(post.objectId);
    };

    const formatTimestamp = (timestamp) => {
      const date = new Date(timestamp);
      const now = new Date();
      const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
      
      if (diffInHours < 1) return 'Just now';
      if (diffInHours < 24) return `${diffInHours}h ago`;
      return date.toLocaleDateString();
    };

    return (
      <div className="post-card" data-name="post-card" data-file="components/PostCard.js">
        {/* Post Header */}
        <div className="flex items-center gap-3 mb-3">
          <div 
            className="w-12 h-12 rounded-full bg-[var(--primary-color)] flex items-center justify-center text-white font-semibold cursor-pointer border-2 border-[var(--border-color)]"
            onClick={() => onViewProfile(post.author)}
          >
            {post.author?.name?.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1">
            <h4 
              className="font-semibold cursor-pointer hover:text-[var(--primary-color)]"
              onClick={() => onViewProfile(post.author)}
            >
              {post.author?.name}
            </h4>
            <p className="text-sm text-[var(--text-muted)]">{post.author?.bio}</p>
            <p className="text-xs text-[var(--text-muted)]">
              {formatTimestamp(post.objectData.timestamp)}
            </p>
          </div>
        </div>

        {/* Post Content */}
        <div className="mb-4">
          <p className="text-[var(--text-primary)] whitespace-pre-wrap">
            {post.objectData.content}
          </p>
          
          {post.objectData.media && (
            <div className="mt-3">
              {post.objectData.media.type === 'image' ? (
                <img
                  src={post.objectData.media.url}
                  alt="Post media"
                  className="w-full rounded-lg max-h-96 object-cover"
                />
              ) : (
                <video
                  src={post.objectData.media.url}
                  controls
                  className="w-full rounded-lg max-h-96"
                />
              )}
            </div>
          )}
        </div>

        {/* Post Stats */}
        <div className="flex items-center text-sm text-[var(--text-muted)] mb-3">
          <span>{post.objectData.likes?.length || 0} likes</span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-4 border-t border-[var(--border-color)] pt-3">
          <button
            onClick={handleLike}
            className={`like-button ${isLiked ? 'liked' : ''}`}
          >
            <div className={`icon-heart text-xl ${isLiked ? 'text-red-500' : 'text-[var(--text-secondary)]'}`}></div>
            <span className={isLiked ? 'text-red-500' : 'text-[var(--text-secondary)]'}>
              {isLiked ? 'Liked' : 'Like'}
            </span>
          </button>
          
          <button className="like-button">
            <div className="icon-share text-xl text-[var(--text-secondary)]"></div>
            <span className="text-[var(--text-secondary)]">Share</span>
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('PostCard component error:', error);
    return null;
  }
}