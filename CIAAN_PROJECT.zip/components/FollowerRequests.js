function FollowerRequests({ currentUser, onBack }) {
  try {
    const [requests, setRequests] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
      loadFollowRequests();
    }, []);

    const loadFollowRequests = async () => {
      try {
        const followRequests = await getFollowRequests(currentUser.objectId);
        const users = await getAllUsers();
        
        const enrichedRequests = followRequests.map(request => {
          const fromUser = users.find(u => u.objectId === request.objectData.fromUserId);
          return {
            ...request,
            fromUser: fromUser ? fromUser.objectData : null
          };
        });
        
        setRequests(enrichedRequests);
      } catch (error) {
        console.error('Failed to load follow requests:', error);
      } finally {
        setLoading(false);
      }
    };

    const handleAcceptRequest = async (requestId) => {
      try {
        await trickleUpdateObject('follow_request', requestId, { status: 'accepted' });
        setRequests(requests.filter(req => req.objectId !== requestId));
      } catch (error) {
        console.error('Failed to accept request:', error);
      }
    };

    const handleDeclineRequest = async (requestId) => {
      try {
        await trickleDeleteObject('follow_request', requestId);
        setRequests(requests.filter(req => req.objectId !== requestId));
      } catch (error) {
        console.error('Failed to decline request:', error);
      }
    };

    if (loading) {
      return (
        <div className="flex items-center justify-center py-12">
          <div className="w-8 h-8 border-4 border-[var(--primary-color)] border-t-transparent rounded-full animate-spin"></div>
        </div>
      );
    }

    return (
      <div className="space-y-6" data-name="follower-requests" data-file="components/FollowerRequests.js">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-[var(--primary-color)] hover:underline"
        >
          <div className="icon-arrow-left text-lg"></div>
          Back to Home
        </button>

        <div className="card p-6">
          <h2 className="text-xl font-semibold mb-4">Follow Requests</h2>
          
          {requests.length > 0 ? (
            <div className="space-y-4">
              {requests.map(request => (
                <div key={request.objectId} className="flex items-center justify-between p-4 border border-[var(--border-color)] rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-[var(--primary-color)] flex items-center justify-center text-white font-semibold">
                      {request.fromUser?.name?.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-semibold">{request.fromUser?.name}</h3>
                      <p className="text-sm text-[var(--text-muted)]">{request.fromUser?.bio}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleAcceptRequest(request.objectId)}
                      className="btn-primary"
                    >
                      Accept
                    </button>
                    <button
                      onClick={() => handleDeclineRequest(request.objectId)}
                      className="btn-secondary"
                    >
                      Decline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="icon-user-plus text-4xl text-[var(--text-muted)] mb-4"></div>
              <p className="text-[var(--text-muted)]">No follow requests</p>
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('FollowerRequests component error:', error);
    return null;
  }
}