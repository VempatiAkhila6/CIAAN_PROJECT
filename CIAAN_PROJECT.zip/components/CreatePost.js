function CreatePost({ onCreatePost }) {
  try {
    const [content, setContent] = React.useState('');
    const [showMediaOptions, setShowMediaOptions] = React.useState(false);
    const [selectedMedia, setSelectedMedia] = React.useState(null);
    const [isPosting, setIsPosting] = React.useState(false);
    const mediaOptionsRef = React.useRef(null);

    React.useEffect(() => {
      const handleClickOutside = (event) => {
        if (mediaOptionsRef.current && !mediaOptionsRef.current.contains(event.target)) {
          setShowMediaOptions(false);
        }
      };

      if (showMediaOptions) {
        document.addEventListener('mousedown', handleClickOutside);
      }

      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }, [showMediaOptions]);

    const handleSubmit = async () => {
      if (!content.trim()) return;
      
      setIsPosting(true);
      try {
        await onCreatePost(content, selectedMedia);
        setContent('');
        setSelectedMedia(null);
        setShowMediaOptions(false);
      } catch (error) {
        console.error('Failed to create post:', error);
      } finally {
        setIsPosting(false);
      }
    };

    const handleFileUpload = (event) => {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setSelectedMedia({
            type: file.type.startsWith('image/') ? 'image' : 'video',
            url: e.target.result,
            name: file.name
          });
        };
        reader.readAsDataURL(file);
      }
      setShowMediaOptions(false);
    };

    const handleMediaSelect = (type) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = type === 'photo' ? 'image/*' : 'video/*';
      input.onchange = handleFileUpload;
      input.click();
    };

    return (
      <div className="post-card mb-6" data-name="create-post" data-file="components/CreatePost.js">
        <div className="flex gap-3">
          <div className="w-12 h-12 bg-[var(--primary-color)] rounded-full flex items-center justify-center">
            <div className="icon-plus text-white text-xl"></div>
          </div>
          
          <div className="flex-1">
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What's on your mind? Share your professional insights..."
              className="w-full p-3 border border-[var(--border-color)] rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
              rows="3"
            />
            
            {selectedMedia && (
              <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`icon-${selectedMedia.type === 'image' ? 'image' : 'video'} text-lg text-[var(--primary-color)]`}></div>
                    <span className="text-sm font-medium">{selectedMedia.name}</span>
                  </div>
                  <button
                    onClick={() => setSelectedMedia(null)}
                    className="text-[var(--text-muted)] hover:text-[var(--danger-color)]"
                  >
                    <div className="icon-x text-lg"></div>
                  </button>
                </div>
              </div>
            )}
            
            <div className="flex items-center justify-between mt-3">
              <div className="flex items-center gap-2">
                <div className="relative" ref={mediaOptionsRef}>
                  <button
                    onClick={() => setShowMediaOptions(!showMediaOptions)}
                    className="flex items-center gap-2 px-3 py-2 text-[var(--text-secondary)] hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <div className="icon-image text-lg"></div>
                    <span className="text-sm">Photo/Video</span>
                  </button>
                  
                  {showMediaOptions && (
                    <div className="absolute top-full left-0 mt-2 bg-white rounded-lg shadow-lg border border-[var(--border-color)] py-2 z-10 min-w-32">
                      <button
                        onClick={() => handleMediaSelect('photo')}
                        className="w-full text-left px-4 py-2 hover:bg-gray-50 flex items-center gap-3"
                      >
                        <div className="icon-image text-lg text-[var(--primary-color)]"></div>
                        Add Photo
                      </button>
                      <button
                        onClick={() => handleMediaSelect('video')}
                        className="w-full text-left px-4 py-2 hover:bg-gray-50 flex items-center gap-3"
                      >
                        <div className="icon-video text-lg text-[var(--primary-color)]"></div>
                        Add Video
                      </button>
                    </div>
                  )}
                </div>
              </div>
              
              <button
                onClick={handleSubmit}
                disabled={!content.trim() || isPosting}
                className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isPosting ? 'Posting...' : 'Post'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('CreatePost component error:', error);
    return null;
  }
}
