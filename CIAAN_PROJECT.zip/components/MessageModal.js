function MessageModal({ recipient, currentUser, onClose }) {
  try {
    const [message, setMessage] = React.useState('');
    const [sending, setSending] = React.useState(false);

    const handleSend = async () => {
      if (!message.trim()) return;

      setSending(true);
      try {
        // Simulate sending message
        await new Promise(resolve => setTimeout(resolve, 1000));
        setMessage('');
        onClose();
      } catch (error) {
        console.error('Failed to send message:', error);
      } finally {
        setSending(false);
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" data-name="message-modal" data-file="components/MessageModal.js">
        <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[var(--primary-color)] flex items-center justify-center text-white font-semibold">
                {recipient.objectData.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <h3 className="font-semibold">{recipient.objectData.name}</h3>
                <p className="text-sm text-[var(--text-muted)]">Send a message</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-[var(--text-muted)] hover:text-[var(--text-primary)]"
            >
              <div className="icon-x text-xl"></div>
            </button>
          </div>

          <div className="space-y-4">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Write your message..."
              className="input-field resize-none"
              rows="4"
            />

            <div className="flex items-center justify-end gap-3">
              <button
                onClick={onClose}
                className="btn-secondary"
              >
                Cancel
              </button>
              <button
                onClick={handleSend}
                disabled={!message.trim() || sending}
                className="btn-primary disabled:opacity-50"
              >
                {sending ? 'Sending...' : 'Send'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('MessageModal component error:', error);
    return null;
  }
}